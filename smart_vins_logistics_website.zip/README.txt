SMART VINS LOGISTICS WEBSITE

Files:
- index.html: complete responsive website. Open it in a browser to preview.

Free publishing option (Google Sites):
This is a ready-made HTML website, so Google Sites cannot directly import this HTML file.
To publish this exact design free, use a static hosting service such as GitHub Pages:
1. Create/sign in to a free GitHub account at https://github.com
2. Create a new public repository named smart-vins-logistics
3. Upload index.html to the repository root.
4. Open Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch, select main and /(root), then Save.
6. GitHub will provide the public website address after publishing.

The website uses remote Unsplash background photos, so internet access is needed to display those photos.
The quote form prepares an email in the visitor's email app; it does not collect submissions in a database.
WhatsApp button opens a chat to +60 16-902 3051.

Before publishing, confirm that the listed services accurately reflect what your business can arrange.
